#   Copyright 2025 - present The PyMC Developers
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
import numpy as np
import pytest

from pytensor.xtensor import as_xtensor

from pymc import Model
from pymc import distributions as regular_distributions
from pymc.dims import (
    Bernoulli,
    Beta,
    BetaBinomial,
    Binomial,
    Cauchy,
    DiracDelta,
    Exponential,
    Flat,
    Gamma,
    Geometric,
    Gumbel,
    HalfCauchy,
    HalfFlat,
    HalfNormal,
    HalfStudentT,
    HyperGeometric,
    InverseGamma,
    Kumaraswamy,
    Laplace,
    Logistic,
    LogNormal,
    NegativeBinomial,
    Normal,
    Pareto,
    Poisson,
    StudentT,
    Triangular,
    TruncatedNormal,
    Uniform,
    VonMises,
    Wald,
    Weibull,
)
from tests.dims.utils import assert_equivalent_logp_graph, assert_equivalent_random_graph

pytestmark = pytest.mark.filterwarnings("error")


def test_flat():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Flat("x", dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Flat("x", dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_halfflat():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        HalfFlat("x", dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.HalfFlat("x", dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_uniform():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Uniform("x", dims="a")
        Uniform("y", lower=-1, upper=2, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Uniform("x", dims="a")
        regular_distributions.Uniform("y", lower=-1, upper=2, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_uniform_transposed():
    lower = as_xtensor([1, 2, 3], dims="b")
    coords = {"a": range(2), "b": range(3)}
    with Model(coords=coords) as model:
        Uniform("x", lower=lower, upper=4, dims=("a", "b"))
        Uniform("y", lower=lower, upper=4, dims=("b", "a"))

    np.testing.assert_allclose(
        model.compile_logp()(
            {
                "x_interval__": np.zeros((2, 3)),
                "y_interval__": np.zeros((3, 2)),
            }
        ),
        -16.635532,  # Reference value obtained manually
    )


def test_conditionally_constrained_transform_not_supported():
    coords = {"a": range(2), "b": range(3)}
    with Model(coords=coords):
        x = Uniform("x", dims=("a", "b"))
        with pytest.raises(NotImplementedError, match="must be a constant"):
            # We don't have good infrastructure to allow conditionally constrained transforms for derived/transposed RVs
            y = Uniform("y", lower=-abs(x), upper=abs(x).T, dims=("b", "a"))


def test_normal():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Normal("x", dims="a")
        Normal("y", mu=2, sigma=3, dims="a")
        Normal("z", mu=-2, tau=3, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Normal("x", dims="a")
        regular_distributions.Normal("y", mu=2, sigma=3, dims="a")
        regular_distributions.Normal("z", mu=-2, tau=3, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_halfnormal():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        HalfNormal("x", dims="a")
        HalfNormal("y", sigma=3, dims="a")
        HalfNormal("z", tau=3, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.HalfNormal("x", dims="a")
        regular_distributions.HalfNormal("y", sigma=3, dims="a")
        regular_distributions.HalfNormal("z", tau=3, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_truncated_normal():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        TruncatedNormal("x", lower=-1, dims="a")
        TruncatedNormal("y", upper=1, dims="a")
        TruncatedNormal("z", lower=-1, upper=1, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.TruncatedNormal("x", lower=-1, dims="a")
        regular_distributions.TruncatedNormal("y", upper=1, dims="a")
        regular_distributions.TruncatedNormal("z", lower=-1, upper=1, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_lognormal():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        LogNormal("x", dims="a")
        LogNormal("y", mu=2, sigma=3, dims="a")
        LogNormal("z", mu=-2, tau=3, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.LogNormal("x", dims="a")
        regular_distributions.LogNormal("y", mu=2, sigma=3, dims="a")
        regular_distributions.LogNormal("z", mu=-2, tau=3, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_studentt():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        StudentT("x", nu=1, dims="a")
        StudentT("y", nu=1, mu=2, sigma=3, dims="a")
        StudentT("z", nu=1, mu=-2, lam=3, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.StudentT("x", nu=1, dims="a")
        regular_distributions.StudentT("y", nu=1, mu=2, sigma=3, dims="a")
        regular_distributions.StudentT("z", nu=1, mu=-2, lam=3, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_halfstudentt():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        HalfStudentT("x", nu=1, dims="a")
        HalfStudentT("y", nu=1, sigma=3, dims="a")
        HalfStudentT("z", nu=1, lam=3, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.HalfStudentT("x", nu=1, dims="a")
        regular_distributions.HalfStudentT("y", nu=1, sigma=3, dims="a")
        regular_distributions.HalfStudentT("z", nu=1, lam=3, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_cauchy():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Cauchy("x", alpha=1, beta=2, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Cauchy("x", alpha=1, beta=2, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_halfcauchy():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        HalfCauchy("x", beta=2, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.HalfCauchy("x", beta=2, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_beta():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Beta("w", alpha=1, beta=1, dims="a")
        Beta("x", mu=0.5, sigma=0.1, dims="a")
        Beta("y", mu=0.5, nu=10, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Beta("w", alpha=1, beta=1, dims="a")
        regular_distributions.Beta("x", mu=0.5, sigma=0.1, dims="a")
        regular_distributions.Beta("y", mu=0.5, nu=10, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_laplace():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Laplace("x", dims="a")
        Laplace("y", mu=1, b=2, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Laplace("x", mu=0, b=1, dims="a")
        regular_distributions.Laplace("y", mu=1, b=2, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_exponential():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Exponential("x", dims="a")
        Exponential("y", lam=2, dims="a")
        Exponential("z", scale=3, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Exponential("x", dims="a")
        regular_distributions.Exponential("y", lam=2, dims="a")
        regular_distributions.Exponential("z", scale=3, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_gamma():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        # Gamma("w", alpha=1, beta=1, dims="a")
        Gamma("x", mu=2, sigma=3, dims="a")

    with Model(coords=coords) as reference_model:
        # regular_distributions.Gamma("w", alpha=1, beta=1, dims="a")
        regular_distributions.Gamma("x", mu=2, sigma=3, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_inverse_gamma():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        InverseGamma("w", alpha=1, beta=1, dims="a")
        InverseGamma("x", mu=2, sigma=3, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.InverseGamma("w", alpha=1, beta=1, dims="a")
        regular_distributions.InverseGamma("x", mu=2, sigma=3, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_wald():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Wald("x", mu=2, lam=3, dims="a")
        Wald("y", lam=3, phi=1.5, alpha=1, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Wald("x", mu=2, lam=3, dims="a")
        regular_distributions.Wald("y", lam=3, phi=1.5, alpha=1, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_weibull():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Weibull("x", alpha=1, beta=2, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Weibull("x", alpha=1, beta=2, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_pareto():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Pareto("x", alpha=2, m=5, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Pareto("x", alpha=2, m=5, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_gumbel():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Gumbel("x", mu=0.5, beta=1.2, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Gumbel("x", mu=0.5, beta=1.2, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_logistic():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Logistic("x", mu=0.5, s=1.2, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Logistic("x", mu=0.5, s=1.2, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_vonmises():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        VonMises("x", mu=0.5, kappa=2.0, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.VonMises("x", mu=0.5, kappa=2.0, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_triangular():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Triangular("x", lower=0, upper=1, c=0.4, dims="a")
        Triangular("y", dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Triangular("x", lower=0, upper=1, c=0.4, dims="a")
        regular_distributions.Triangular("y", dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_bernoulli():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Bernoulli("x", p=0.3, dims="a")
        Bernoulli("y", logit_p=-0.5, dims="a")
        with pytest.raises(ValueError, match="Can't specify both p and logit_p"):
            Bernoulli("z", p=0.3, logit_p=-0.5, dims="a")
        with pytest.raises(ValueError, match="Must specify either p or logit_p"):
            Bernoulli("w", dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Bernoulli("x", p=0.3, dims="a")
        regular_distributions.Bernoulli("y", logit_p=-0.5, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_betabinom():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        BetaBinomial("x", n=10, alpha=2, beta=3, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.BetaBinomial("x", n=10, alpha=2, beta=3, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_binomial():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Binomial("x", n=10, p=0.3, dims="a")
        Binomial("y", n=10, logit_p=-0.5, dims="a")
        with pytest.raises(ValueError, match="Can't specify both p and logit_p"):
            Binomial("z", n=10, p=0.3, logit_p=-0.5, dims="a")
        with pytest.raises(ValueError, match="Must specify either p or logit_p"):
            Binomial("w", n=10, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Binomial("x", n=10, p=0.3, dims="a")
        regular_distributions.Binomial("y", n=10, logit_p=-0.5, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_geometric():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Geometric("x", p=0.3, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Geometric("x", p=0.3, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_hypergeometric():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        HyperGeometric("x", N=50, k=20, n=10, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.HyperGeometric("x", N=50, k=20, n=10, dims="a")


def test_kumaraswamy():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Kumaraswamy("x", a=2, b=5, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Kumaraswamy("x", a=2, b=5, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_poisson():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        Poisson("x", mu=2.0, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.Poisson("x", mu=2.0, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_negative_binomial():
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        NegativeBinomial("x", mu=5.0, alpha=2.0, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.NegativeBinomial("x", mu=5.0, alpha=2.0, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


@pytest.mark.parametrize("c", [5.0, 3], ids=["float", "int"])
def test_diracdelta(c):
    coords = {"a": range(3)}
    with Model(coords=coords) as model:
        DiracDelta("x", c, dims="a")

    with Model(coords=coords) as reference_model:
        regular_distributions.DiracDelta("x", c, dims="a")

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_diracdelta_scalar():
    with Model() as model:
        x = DiracDelta("x", 2.0)
    assert x.type.dims == ()

    with Model() as reference_model:
        regular_distributions.DiracDelta("x", 2.0)

    assert_equivalent_random_graph(model, reference_model)
    assert_equivalent_logp_graph(model, reference_model)


def test_diracdelta_observed():
    coords = {"a": range(3)}
    observed = as_xtensor(np.array([1.0, 1.0, 1.0]), dims=("a",))
    with Model(coords=coords) as model:
        DiracDelta("x", 1.0, dims="a", observed=observed)

    with Model(coords=coords) as reference_model:
        regular_distributions.DiracDelta("x", 1.0, dims="a", observed=observed.values)

    assert_equivalent_logp_graph(model, reference_model)
