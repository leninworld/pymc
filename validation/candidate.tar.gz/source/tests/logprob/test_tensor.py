#   Copyright 2024 - present The PyMC Developers
#
#   Licensed under the Apache License, Version 2.0 (the "License");
#   you may not use this file except in compliance with the License.
#   You may obtain a copy of the License at
#
#       http://www.apache.org/licenses/LICENSE-2.0
#
#   Unless required by applicable law or agreed to in writing, software
#   distributed under the License is distributed on an "AS IS" BASIS,
#   WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
#   See the License for the specific language governing permissions and
#   limitations under the License.
#
#   MIT License
#
#   Copyright (c) 2021-2022 aesara-devs
#
#   Permission is hereby granted, free of charge, to any person obtaining a copy
#   of this software and associated documentation files (the "Software"), to deal
#   in the Software without restriction, including without limitation the rights
#   to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
#   copies of the Software, and to permit persons to whom the Software is
#   furnished to do so, subject to the following conditions:
#
#   The above copyright notice and this permission notice shall be included in all
#   copies or substantial portions of the Software.
#
#   THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
#   IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
#   FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
#   AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
#   LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
#   OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
#   SOFTWARE.

import numpy as np
import pytensor
import pytest

from pytensor import tensor as pt
from pytensor.assumptions import assume
from pytensor.compile.ops import DeepCopyOp
from pytensor.graph import RewriteDatabaseQuery
from pytensor.tensor.random.type import random_generator_type
from scipy import stats as st

import pymc as pm

from pymc.logprob.basic import conditional_logp, icdf, logcdf, logp
from pymc.logprob.rewriting import logprob_rewrites_db
from pymc.testing import assert_no_rvs


def test_bcast_rv_logp():
    """Test that derived logp for broadcasted RV is correct"""

    x_rv = pt.random.normal(name="x")
    broadcasted_x_rv = pt.broadcast_to(x_rv, (2,))
    broadcasted_x_rv.name = "broadcasted_x"
    broadcasted_x_vv = broadcasted_x_rv.clone()

    logp = conditional_logp({broadcasted_x_rv: broadcasted_x_vv})
    logp_combined = pt.add(*logp.values())
    valid_logp = logp_combined.eval({broadcasted_x_vv: [0, 0]})

    # The broadcast dimension is consumed like a support dimension
    assert valid_logp.shape == ()
    assert np.isclose(valid_logp, st.norm.logpdf(0))

    # It's not possible for broadcasted dimensions to have different values
    invalid_logp = logp_combined.eval({broadcasted_x_vv: [0, 1]})
    assert invalid_logp == -np.inf


def test_measurable_make_vector():
    base1_rv = pt.random.normal(name="base1")
    base2_rv = pt.random.halfnormal(name="base2")
    base3_rv = pt.random.exponential(name="base3")
    y_rv = pt.stack((base1_rv, base2_rv, base3_rv))
    y_rv.name = "y"

    base1_vv = base1_rv.clone()
    base2_vv = base2_rv.clone()
    base3_vv = base3_rv.clone()
    y_vv = y_rv.clone()

    ref_logp = conditional_logp({base1_rv: base1_vv, base2_rv: base2_vv, base3_rv: base3_vv})
    ref_logp_combined = pt.sum([pt.sum(factor) for factor in ref_logp.values()])

    make_vector_logp = logp(y_rv, y_vv)

    base1_testval = base1_rv.eval()
    base2_testval = base2_rv.eval()
    base3_testval = base3_rv.eval()
    y_testval = np.stack((base1_testval, base2_testval, base3_testval))

    ref_logp_eval_eval = ref_logp_combined.eval(
        {base1_vv: base1_testval, base2_vv: base2_testval, base3_vv: base3_testval}
    )
    make_vector_logp_eval = make_vector_logp.eval({y_vv: y_testval})

    assert make_vector_logp_eval.shape == y_testval.shape
    assert np.isclose(make_vector_logp_eval.sum(), ref_logp_eval_eval)


def test_measurable_make_vector_with_constant_input():
    base1_rv = pt.random.normal(name="base1")
    base2_rv = pt.random.halfnormal(name="base2")
    y_rv = pt.stack((base1_rv, pt.constant(0.0), base2_rv))
    y_rv.name = "y"

    base1_vv = base1_rv.clone()
    base2_vv = base2_rv.clone()
    y_vv = y_rv.clone()

    ref_logp = conditional_logp({base1_rv: base1_vv, base2_rv: base2_vv})
    ref_logp_combined = pt.sum([pt.sum(factor) for factor in ref_logp.values()])
    y_logp = logp(y_rv, y_vv)

    base1_testval = base1_rv.eval()
    base2_testval = base2_rv.eval()
    y_testval = np.stack((base1_testval, 0.0, base2_testval)).astype(y_vv.dtype)

    ref_logp_eval = ref_logp_combined.eval({base1_vv: base1_testval, base2_vv: base2_testval})
    y_logp_eval = y_logp.eval({y_vv: y_testval})

    assert y_logp_eval.shape == y_testval.shape
    assert np.isclose(y_logp_eval.sum(), ref_logp_eval)

    y_testval_bad = y_testval.copy()
    y_testval_bad[1] = 1.0
    y_logp_eval_bad = y_logp.eval({y_vv: y_testval_bad})
    assert y_logp_eval_bad[1] == -np.inf


@pytest.mark.parametrize("reverse", (False, True))
def test_measurable_make_vector_interdependent(reverse):
    """Test that we can obtain a proper graph when stacked RVs depend on each other"""
    x = pt.random.normal(name="x")
    y_rvs = []
    prev_rv = x
    for i in range(3):
        next_rv = pt.random.normal(prev_rv + 1, name=f"y{i}")
        y_rvs.append(next_rv)
        prev_rv = next_rv

    if reverse:
        y_rvs = y_rvs[::-1]

    ys = pt.stack(y_rvs)
    ys.name = "ys"

    x_vv = x.clone()
    ys_vv = ys.clone()

    logp = conditional_logp({x: x_vv, ys: ys_vv})
    logp_combined = pt.sum([pt.sum(factor) for factor in logp.values()])
    assert_no_rvs(logp_combined)

    y0_vv = y_rvs[0].clone()
    y1_vv = y_rvs[1].clone()
    y2_vv = y_rvs[2].clone()

    ref_logp = conditional_logp({x: x_vv, y_rvs[0]: y0_vv, y_rvs[1]: y1_vv, y_rvs[2]: y2_vv})
    ref_logp_combined = pt.sum([pt.sum(factor) for factor in ref_logp.values()])

    rng = np.random.default_rng()
    x_vv_test = rng.normal()
    ys_vv_test = rng.normal(size=3)
    np.testing.assert_allclose(
        logp_combined.eval({x_vv: x_vv_test, ys_vv: ys_vv_test}).sum(),
        ref_logp_combined.eval(
            {x_vv: x_vv_test, y0_vv: ys_vv_test[0], y1_vv: ys_vv_test[1], y2_vv: ys_vv_test[2]}
        ),
    )


@pytest.mark.parametrize("reverse", (False, True))
def test_measurable_join_interdependent(reverse):
    """Test that we can obtain a proper graph when stacked RVs depend on each other"""
    x = pt.random.normal(name="x")
    y_rvs = []
    prev_rv = x
    for i in range(3):
        next_rv = pt.random.normal(prev_rv + 1, name=f"y{i}", size=(1, 2))
        y_rvs.append(next_rv)
        prev_rv = next_rv

    if reverse:
        y_rvs = y_rvs[::-1]

    ys = pt.concatenate(y_rvs, axis=0)
    ys.name = "ys"

    x_vv = x.clone()
    ys_vv = ys.clone()

    logp = conditional_logp({x: x_vv, ys: ys_vv})
    logp_combined = pt.sum([pt.sum(factor) for factor in logp.values()])
    assert_no_rvs(logp_combined)

    y0_vv = y_rvs[0].clone()
    y1_vv = y_rvs[1].clone()
    y2_vv = y_rvs[2].clone()

    ref_logp = conditional_logp({x: x_vv, y_rvs[0]: y0_vv, y_rvs[1]: y1_vv, y_rvs[2]: y2_vv})
    ref_logp_combined = pt.sum([pt.sum(factor) for factor in ref_logp.values()])

    rng = np.random.default_rng()
    x_vv_test = rng.normal()
    ys_vv_test = rng.normal(size=(3, 2))
    np.testing.assert_allclose(
        logp_combined.eval({x_vv: x_vv_test, ys_vv: ys_vv_test}),
        ref_logp_combined.eval(
            {
                x_vv: x_vv_test,
                y0_vv: ys_vv_test[0:1],
                y1_vv: ys_vv_test[1:2],
                y2_vv: ys_vv_test[2:3],
            }
        ),
    )


def test_measurable_join_with_constant_input():
    base1_rv = pt.random.normal(size=(2,), name="base1")
    base2_rv = pt.random.exponential(size=(3,), name="base2")
    const = pt.constant(np.array([0.0, 0.0, 0.0]))
    y_rv = pt.join(0, base1_rv, const, base2_rv)
    y_rv.name = "y"

    base1_vv = base1_rv.clone()
    base2_vv = base2_rv.clone()
    y_vv = y_rv.clone()

    ref_logp = conditional_logp({base1_rv: base1_vv, base2_rv: base2_vv})
    ref_logp_combined = pt.sum([pt.sum(factor) for factor in ref_logp.values()])
    y_logp = logp(y_rv, y_vv)

    base1_testval = base1_rv.eval()
    base2_testval = base2_rv.eval()
    y_testval = np.concatenate([base1_testval, np.zeros(3), base2_testval]).astype(y_vv.dtype)

    ref_logp_eval = ref_logp_combined.eval({base1_vv: base1_testval, base2_vv: base2_testval})
    y_logp_eval = y_logp.eval({y_vv: y_testval})

    assert y_logp_eval.shape == y_testval.shape
    assert np.isclose(y_logp_eval.sum(), ref_logp_eval)

    y_testval_bad = y_testval.copy()
    y_testval_bad[2] = 1.0
    y_logp_eval_bad = y_logp.eval({y_vv: y_testval_bad})
    assert y_logp_eval_bad[2] == -np.inf


@pytest.mark.parametrize(
    "size1, size2, axis, concatenate",
    [
        ((5,), (3,), 0, True),
        ((5,), (3,), -1, True),
        ((5, 2), (3, 2), 0, True),
        ((2, 5), (2, 3), 1, True),
        ((2, 5), (2, 5), 0, False),
        ((2, 5), (2, 5), 1, False),
        ((2, 5), (2, 5), 2, False),
    ],
)
def test_measurable_join_univariate(size1, size2, axis, concatenate):
    base1_rv = pt.random.normal(size=size1, name="base1")
    base2_rv = pt.random.exponential(size=size2, name="base2")
    if concatenate:
        y_rv = pt.concatenate((base1_rv, base2_rv), axis=axis)
    else:
        y_rv = pt.stack((base1_rv, base2_rv), axis=axis)
    y_rv.name = "y"

    base1_vv = base1_rv.clone()
    base2_vv = base2_rv.clone()
    y_vv = y_rv.clone()

    base_logps = list(conditional_logp({base1_rv: base1_vv, base2_rv: base2_vv}).values())
    if concatenate:
        base_logps = pt.concatenate(base_logps, axis=axis)
    else:
        base_logps = pt.stack(base_logps, axis=axis)
    y_logp = logp(y_rv, y_vv)
    assert_no_rvs(y_logp)

    base1_testval = base1_rv.eval()
    base2_testval = base2_rv.eval()
    if concatenate:
        y_testval = np.concatenate((base1_testval, base2_testval), axis=axis)
    else:
        y_testval = np.stack((base1_testval, base2_testval), axis=axis)
    np.testing.assert_allclose(
        base_logps.eval({base1_vv: base1_testval, base2_vv: base2_testval}),
        y_logp.eval({y_vv: y_testval}),
    )


@pytest.mark.parametrize(
    "size1, supp_size1, size2, supp_size2, axis, concatenate, logp_axis",
    [
        (None, 2, None, 2, 0, True, 0),
        (None, 2, None, 2, -1, True, 0),
        ((5,), 2, (3,), 2, 0, True, 0),
        ((5,), 2, (3,), 2, -2, True, 0),
        ((2,), 5, (2,), 3, 1, True, 0),
        ((5, 6), 10, (5, 1), 10, 1, True, 1),
        ((5, 6), 10, (5, 1), 10, -2, True, 1),
        ((2,), 5, (2,), 5, 0, False, 0),
        ((2,), 5, (2,), 5, 1, False, 1),
        ((5, 6), 10, (5, 6), 10, 2, False, 2),
    ],
)
def test_measurable_join_multivariate(
    size1, supp_size1, size2, supp_size2, axis, concatenate, logp_axis
):
    base1_rv = pt.random.multivariate_normal(
        np.zeros(supp_size1), np.eye(supp_size1), size=size1, name="base1"
    )
    base2_rv = pt.random.dirichlet(np.ones(supp_size2), size=size2, name="base2")
    if concatenate:
        y_rv = pt.concatenate((base1_rv, base2_rv), axis=axis)
    else:
        y_rv = pt.stack((base1_rv, base2_rv), axis=axis)
    y_rv.name = "y"

    base1_vv = base1_rv.clone()
    base2_vv = base2_rv.clone()
    y_vv = y_rv.clone()

    y_logp = logp(y_rv, y_vv)
    assert_no_rvs(y_logp)

    base_logps = [
        pt.atleast_1d(logp)
        for logp in conditional_logp({base1_rv: base1_vv, base2_rv: base2_vv}).values()
    ]
    if concatenate:
        expected_logp = pt.concatenate(base_logps, axis=logp_axis)
    else:
        expected_logp = pt.stack(base_logps, axis=logp_axis)

    base1_testval = base1_rv.eval()
    base2_testval = base2_rv.eval()
    if concatenate:
        y_testval = np.concatenate((base1_testval, base2_testval), axis=axis)
    else:
        y_testval = np.stack((base1_testval, base2_testval), axis=axis)
    np.testing.assert_allclose(
        expected_logp.eval({base1_vv: base1_testval, base2_vv: base2_testval}),
        y_logp.eval({y_vv: y_testval}),
    )


def test_join_mixed_ndim_supp():
    base1_rv = pt.random.normal(size=3, name="base1")
    base2_rv = pt.random.dirichlet(np.ones(3), name="base2")
    y_rv = pt.concatenate((base1_rv, base2_rv), axis=0)

    y_vv = y_rv.clone()
    with pytest.raises(ValueError, match="Joined logps have different number of dimensions"):
        logp(y_rv, y_vv)


@pytensor.config.change_flags(cxx="")
@pytest.mark.parametrize(
    "ds_order",
    [
        (0, 2, 1),  # Swap
        (2, 1, 0),  # Swap
        (1, 2, 0),  # Swap
        (0, 1, 2, "x"),  # Expand
        ("x", 0, 1, 2),  # Expand
        (0, 2),  # Drop
        (2, 0),  # Swap and drop
        (2, 1, "x", 0),  # Swap and expand
        ("x", 0, 2),  # Expand and drop
        (2, "x", 0),  # Swap, expand and drop
    ],
)
@pytest.mark.parametrize("multivariate", (False, True))
def test_measurable_dimshuffle(ds_order, multivariate):
    if multivariate:
        base_rv = pt.random.dirichlet([1, 2, 3], size=(2, 1))
    else:
        base_rv = pt.exp(pt.random.beta(1, 2, size=(2, 1, 3)))

    ds_rv = base_rv.dimshuffle(ds_order)
    base_vv = base_rv.clone()
    ds_vv = ds_rv.clone()

    # Remove support dimension axis from ds_order (i.e., 2, for multivariate)
    if multivariate:
        logp_ds_order = [o for o in ds_order if o == "x" or o < 2]
    else:
        logp_ds_order = ds_order

    ref_logp = logp(base_rv, base_vv).dimshuffle(logp_ds_order)

    # Disable local_dimshuffle_rv_lift to test fallback logprob rewrite
    ir_rewriter = logprob_rewrites_db.query(
        RewriteDatabaseQuery(include=["basic"]).excluding("dimshuffle_lift")
    )
    ds_logp = conditional_logp({ds_rv: ds_vv}, ir_rewriter=ir_rewriter)
    ds_logp_combined = pt.add(*ds_logp.values())
    assert ds_logp_combined is not None

    ref_logp_fn = pytensor.function([base_vv], ref_logp)
    ds_logp_fn = pytensor.function([ds_vv], ds_logp_combined)

    base_test_value = base_rv.eval()
    ds_test_value = pt.constant(base_test_value).dimshuffle(ds_order).eval()

    np.testing.assert_array_equal(ref_logp_fn(base_test_value), ds_logp_fn(ds_test_value))


def test_unmeasurable_dimshuffles():
    # Test that graphs with DimShuffles that cannot be lifted/merged fail

    # Initial support axis is at axis=-1
    x = pt.random.dirichlet(
        np.ones((3,)),
        size=(4, 2),
    )
    # Support axis is now at axis=-2
    y = x.dimshuffle((0, 2, 1))
    # Downstream dimshuffle will not be lifted through cumsum. If it ever is,
    # we will need a different measurable Op example
    z = pt.cumsum(y, axis=-2)
    # Support axis is now at axis=-3
    w = z.dimshuffle((1, 0, 2))

    w_vv = w.clone()
    # TODO: Check that logp is correct if this type of graphs is ever supported
    with pytest.raises(RuntimeError, match="could not be derived"):
        conditional_logp({w: w_vv})


class TestMeasurableSplit:
    def test_univariate(self):
        rng = np.random.default_rng(388)
        mu = np.arange(6)[:, None]
        sigma = np.arange(5) + 1

        x = pt.random.normal(mu, sigma, size=(6, 5), name="x")

        # axis=0
        x_parts = pt.split(x, splits_size=[2, 4], n_splits=2, axis=0)
        x_parts_vv = [x_part.clone() for x_part in x_parts]
        logp_parts = list(conditional_logp(dict(zip(x_parts, x_parts_vv))).values())

        logp_fn = pytensor.function(x_parts_vv, logp_parts)
        x_parts_test = [rng.normal(size=x_part.type.shape) for x_part in x_parts_vv]
        logp_x1_eval, logp_x2_eval = logp_fn(*x_parts_test)
        np.testing.assert_allclose(
            logp_x1_eval,
            st.norm.logpdf(x_parts_test[0], mu[:2], sigma),
        )
        np.testing.assert_allclose(
            logp_x2_eval,
            st.norm.logpdf(x_parts_test[1], mu[2:], sigma),
        )

        # axis=1
        x_parts = pt.split(x, splits_size=[2, 1, 2], n_splits=3, axis=1)
        x_parts_vv = [x_part.clone() for x_part in x_parts]
        logp_parts = list(conditional_logp(dict(zip(x_parts, x_parts_vv))).values())

        logp_fn = pytensor.function(x_parts_vv, logp_parts)
        x_parts_test = [rng.normal(size=x_part.type.shape) for x_part in x_parts_vv]
        logp_x1_eval, logp_x2_eval, logp_x3_eval = logp_fn(*x_parts_test)
        np.testing.assert_allclose(
            logp_x1_eval,
            st.norm.logpdf(x_parts_test[0], mu, sigma[:2]),
        )
        np.testing.assert_allclose(
            logp_x2_eval,
            st.norm.logpdf(x_parts_test[1], mu, sigma[2:3]),
        )
        np.testing.assert_allclose(
            logp_x3_eval,
            st.norm.logpdf(x_parts_test[2], mu, sigma[3:]),
        )

    def test_multivariate(self):
        @np.vectorize(signature=("(n),(n)->()"))
        def scipy_dirichlet_logpdf(x, alpha):
            """Compute the logpdf of a Dirichlet distribution using scipy."""
            return st.dirichlet.logpdf(x, alpha)

        # (3, 5) Dirichlet
        rng = np.random.default_rng(426)
        rng_pt = random_generator_type("rng")
        alpha = np.linspace(1, 10, 5) * np.array([1, 10, 100])[:, None]
        x = pt.random.dirichlet(alpha, rng=rng_pt)

        # axis=-2 (i.e., 0, - batch dimension)
        x_parts = pt.split(x, splits_size=[2, 1], n_splits=2, axis=-2)
        x_parts_vv = [x_part.clone() for x_part in x_parts]
        logp_parts = list(conditional_logp(dict(zip(x_parts, x_parts_vv))).values())
        assert logp_parts[0].type.shape == (2,)
        assert logp_parts[1].type.shape == (1,)

        logp_fn = pytensor.function(x_parts_vv, logp_parts)
        x_parts_test = pytensor.function([rng_pt], x_parts)(rng)
        logp_x1_eval, logp_x2_eval = logp_fn(*x_parts_test)
        np.testing.assert_allclose(
            logp_x1_eval,
            scipy_dirichlet_logpdf(x_parts_test[0], alpha[:2]),
        )
        np.testing.assert_allclose(
            logp_x2_eval,
            scipy_dirichlet_logpdf(x_parts_test[1], alpha[2:]),
        )

        # axis=-1 (i.e., 1, - support dimension)
        x_parts = pt.split(x, splits_size=[2, 3], n_splits=2, axis=-1)
        x_parts_vv = [x_part.clone() for x_part in x_parts]
        logp_parts = list(conditional_logp(dict(zip(x_parts, x_parts_vv))).values())

        assert logp_parts[0].type.shape == (3,)
        assert logp_parts[1].type.shape == (3,)
        logp_fn = pytensor.function(x_parts_vv, logp_parts)

        x_parts_test = pytensor.function([rng_pt], x_parts)(rng)
        logp_x1_eval, logp_x2_eval = logp_fn(*x_parts_test)
        np.testing.assert_allclose(logp_x1_eval * 3, logp_x2_eval * 2)
        logp_total = logp_x1_eval + logp_x2_eval
        np.testing.assert_allclose(
            logp_total,
            scipy_dirichlet_logpdf(np.concatenate(x_parts_test, axis=1), alpha),
        )

    @pytest.mark.xfail(
        reason="Rewrite from partial split to split on subtensor not implemented yet"
    )
    def test_not_all_splits_used(self):
        x = pt.random.normal(mu=pt.arange(6), name="x")
        x_parts = pt.split(x, splits_size=[2, 2, 2], n_splits=3, axis=0)[
            ::2
        ]  # Only use first two splits
        x_parts_vv = [x_part.clone() for x_part in x_parts]
        logp_parts = list(conditional_logp(dict(zip(x_parts, x_parts_vv))).values())
        assert len(logp_parts) == 2

        logp_fn = pytensor.function(x_parts_vv, logp_parts)
        x_parts_test = [x_part.eval() for x_part in x_parts_vv]
        logp_x1_eval, logp_x2_eval = logp_fn(*x_parts_test)
        np.testing.assert_allclose(
            logp_x1_eval,
            st.norm.logpdf(x_parts_test[0], loc=[0, 1]),
        )
        np.testing.assert_allclose(
            logp_x2_eval,
            st.norm.logpdf(x_parts_test[1], loc=[4, 5]),
        )

    def test_not_all_splits_used_core_dim(self):
        # TODO: We could support this for univariate/batch dimensions by rewriting as
        # split(x, splits_size=[2, 2, 2], n_splits=3, axis=1)[:2] -> split(x[:-2], splits_size=[2, 2], n_splits=2, axis=1)
        # And letting logp infer the probability of x[:-2]
        x = pt.random.dirichlet(alphas=pt.ones(6), name="x")
        x_parts = pt.split(x, splits_size=[2, 2, 2], n_splits=3, axis=0)[
            :2
        ]  # Only use first two splits
        x_parts_vv = [x_part.clone() for x_part in x_parts]

        with pytest.raises(
            ValueError,
            match="Split logp requires the number of values to match the number of splits",
        ):
            conditional_logp(dict(zip(x_parts, x_parts_vv)))

    @pytest.mark.xfail(reason="Rewrite from subtensor to split not implemented yet")
    def test_subtensor_converted_to_splits(self):
        rng = np.random.default_rng(388)
        x = pt.random.normal(mu=pt.arange(5), name="x")

        x_parts = [x[:2], x[2:3], x[3:]]
        x_parts_vv = [x_part.clone() for x_part in x_parts]
        logp_parts = list(conditional_logp(dict(zip(x_parts, x_parts_vv))).values())
        assert len(logp_parts) == 3
        logp_fn = pytensor.function(x_parts_vv, logp_parts)
        x_parts_test = [rng.normal(size=x_part.type.shape) for x_part in x_parts_vv]
        logp_x1_eval, logp_x2_eval, logp_x3_eval = logp_fn(*x_parts_test)
        np.testing.assert_allclose(logp_x1_eval, st.norm.logpdf(x_parts_test[0], loc=[0, 1]))
        np.testing.assert_allclose(logp_x2_eval, st.norm.logpdf(x_parts_test[1], loc=[2]))
        np.testing.assert_allclose(logp_x3_eval, st.norm.logpdf(x_parts_test[2], loc=[3, 4]))


def test_measurable_broadcast():
    b_shape = pt.vector("b_shape", shape=(3,), dtype=int)

    x = pt.random.normal(size=(3, 1))
    bcast_x = pt.broadcast_to(x, shape=b_shape)
    bcast_x.name = "bcast_x"

    bcast_x_value = bcast_x.clone()
    logp_bcast_x = logp(bcast_x, bcast_x_value)
    logp_fn = pytensor.function([b_shape, bcast_x_value], logp_bcast_x, on_unused_input="ignore")

    # The expanded and broadcast dimensions are consumed like support dimensions:
    # the logp has the base variable's remaining batch shape
    # (assert_allclose also asserts shapes match, if neither is scalar)
    np.testing.assert_allclose(
        logp_fn([1, 3, 1], np.zeros((1, 3, 1))),
        st.norm.logpdf(np.zeros(3)),
    )
    np.testing.assert_allclose(
        logp_fn([1, 3, 5], np.zeros((1, 3, 5))),
        st.norm.logpdf(np.zeros(3)),
    )
    np.testing.assert_allclose(
        logp_fn([2, 3, 5], np.broadcast_to(np.arange(3).reshape(1, 3, 1), (2, 3, 5))),
        st.norm.logpdf(np.arange(3)),
    )
    # Invalid broadcast value
    np.testing.assert_array_equal(
        logp_fn([1, 3, 5], np.arange(3 * 5).reshape(1, 3, 5)),
        np.full(shape=(3,), fill_value=-np.inf),
    )
    # The invalidity check is elementwise over the base batch dimensions: an
    # inconsistent row only invalidates its own logp
    partially_valid = np.broadcast_to(np.arange(3).reshape(1, 3, 1), (1, 3, 5)).copy()
    partially_valid[0, 1, 3] = 99.0
    np.testing.assert_allclose(
        logp_fn([1, 3, 5], partially_valid),
        np.where([True, False, True], st.norm.logpdf(np.arange(3)), -np.inf),
    )


def test_measurable_broadcast_multivariate():
    x = pt.random.dirichlet(pt.ones(3), size=(1,))
    bcast_x = pt.broadcast_to(x, (5, 3))

    bcast_x_value = bcast_x.clone()
    logp_bcast_x = logp(bcast_x, bcast_x_value)

    rng = np.random.default_rng(170)
    row = rng.dirichlet(np.ones(3))
    valid_value = np.broadcast_to(row, (5, 3))
    valid_logp = logp_bcast_x.eval({bcast_x_value: valid_value})
    assert valid_logp.shape == ()
    np.testing.assert_allclose(
        valid_logp,
        st.dirichlet(np.ones(3)).logpdf(row),
    )

    invalid_value = rng.dirichlet(np.ones(3), size=(5,))
    np.testing.assert_array_equal(
        logp_bcast_x.eval({bcast_x_value: invalid_value}),
        -np.inf,
    )


def test_broadcast_not_measurable_behind_other_ops():
    # The broadcast dimensions are degenerate copies; other rewrites would treat them
    # as independent entries (e.g., counting the jacobian of the exp once per copy),
    # so the broadcast is only measurable when directly valued
    x = pt.random.normal()
    y = pt.exp(pt.broadcast_to(x, (3,)))
    with pytest.raises(NotImplementedError):
        logp(y, y.clone())


class TestMeasurableCast:
    def test_float_to_float(self):
        y = pt.cast(pt.random.normal(0.5, 1), "float32")
        y_vv = y.clone()

        y_test = np.float32(0.7)
        np.testing.assert_allclose(
            logp(y, y_vv).eval({y_vv: y_test}),
            st.norm(0.5, 1).logpdf(y_test),
        )
        np.testing.assert_allclose(
            logcdf(y, y_vv).eval({y_vv: y_test}),
            st.norm(0.5, 1).logcdf(y_test),
        )
        np.testing.assert_allclose(
            icdf(y, 0.3).eval(),
            st.norm(0.5, 1).ppf(0.3),
        )

    def test_discrete_to_float(self):
        y = pt.cast(pt.random.poisson(3), "float64")
        y_vv = y.clone()

        np.testing.assert_allclose(
            logp(y, y_vv).eval({y_vv: 3.0}),
            st.poisson(3).logpmf(3),
        )
        # P(cast(X) <= 3.9) = P(X <= 3)
        np.testing.assert_allclose(
            logcdf(y, y_vv).eval({y_vv: 3.9}),
            st.poisson(3).logcdf(3),
        )

        bern = pt.cast(pt.random.bernoulli(0.3), "float64")
        bern_icdf = icdf(bern, 0.8)
        assert bern_icdf.type.dtype == "float64"
        np.testing.assert_allclose(bern_icdf.eval(), st.bernoulli(0.3).ppf(0.8))

    def test_bool_to_int(self):
        y = pt.cast(pt.random.bernoulli(0.3), "int64")
        y_vv = y.clone()
        np.testing.assert_allclose(
            logp(y, y_vv).eval({y_vv: 1}),
            st.bernoulli(0.3).logpmf(1),
        )

    @pytest.mark.parametrize(
        "value, lower, upper",
        [(1, 1, 2), (0, -1, 1), (-1, -2, -1)],
        ids=["positive", "zero", "negative"],
    )
    def test_float_to_int(self, value, lower, upper):
        # The cast rounds towards zero, pooling (-1, 1) at zero
        y = pt.cast(pt.random.normal(0.5, 1), "int64")
        y_vv = y.clone()

        np.testing.assert_allclose(
            logp(y, y_vv).eval({y_vv: value}),
            np.log(st.norm(0.5, 1).cdf(upper) - st.norm(0.5, 1).cdf(lower)),
        )

    @pytest.mark.parametrize("rounding_fn", [pt.trunc, pt.floor, pt.ceil, pt.round])
    def test_rounded_float_to_int(self, rounding_fn):
        # The base variable is already supported on the integers, so the cast only
        # relabels the dtype and must not introduce a second truncation
        x = pt.random.normal(0.5, 1)
        y = pt.cast(rounding_fn(x), "int64")
        y_vv = y.clone()

        np.testing.assert_allclose(
            logp(y, y_vv).eval({y_vv: 1}),
            logp(rounding_fn(x), pt.constant(1.0)).eval(),
        )

    @pytest.mark.parametrize("out_dtype", ["bool", "uint8"])
    def test_non_truncating_discretizing_cast_not_measurable(self, out_dtype):
        # Casting to bool tests `x != 0` and casting to an unsigned int wraps around
        # for negative values; neither is the truncation that float -> int performs
        y = pt.cast(pt.random.normal(), out_dtype)
        with pytest.raises(NotImplementedError):
            logp(y, y.clone())

    def test_indirect_discrete_to_float_not_measurable(self):
        # If the cast is not directly valued, downstream rewrites would classify the
        # discrete base variable as continuous (e.g., applying a continuous jacobian)
        y = pt.exp(pt.cast(pt.random.poisson(3), "float64"))
        with pytest.raises(NotImplementedError):
            logp(y, y.clone())


class TestMeasurableIdentityOps:
    def test_scalar_from_tensor(self):
        y = pt.scalar_from_tensor(pt.random.normal(0.5, 1))
        y_vv = y.clone()
        np.testing.assert_allclose(
            logp(y, y_vv).eval({y_vv: 0.7}),
            st.norm(0.5, 1).logpdf(0.7),
        )
        np.testing.assert_allclose(
            logcdf(y, y_vv).eval({y_vv: 0.7}),
            st.norm(0.5, 1).logcdf(0.7),
        )
        np.testing.assert_allclose(
            icdf(y, 0.3).eval(),
            st.norm(0.5, 1).ppf(0.3),
        )

    def test_specify_assumptions(self):
        y = assume(pt.random.normal(pt.arange(4), 1, size=(4,)), "unique_indices")
        y_vv = y.clone()
        y_test = np.zeros(4)
        np.testing.assert_allclose(
            logp(y, y_vv).eval({y_vv: y_test}),
            st.norm(np.arange(4), 1).logpdf(y_test),
        )

        # Identity ops keep composing with other measurable rewrites
        y_exp = pt.exp(assume(pt.random.normal(0.5, 1), "diagonal"))
        y_exp_vv = y_exp.clone()
        np.testing.assert_allclose(
            logp(y_exp, y_exp_vv).eval({y_exp_vv: 2.0}),
            st.lognorm(s=1, scale=np.exp(0.5)).logpdf(2.0),
        )

    def test_deep_copy(self):
        y = DeepCopyOp()(pt.random.normal(0.5, 1))
        y_vv = y.clone()
        np.testing.assert_allclose(
            logp(y, y_vv).eval({y_vv: 0.7}),
            st.norm(0.5, 1).logpdf(0.7),
        )


class TestMeasurableJoinSplitDims:
    def test_join_dims(self):
        rng = np.random.default_rng(163)
        x = pt.random.normal(pt.arange(6).reshape((2, 3)), 1, size=(2, 3))
        y = pt.join_dims(x)
        y_vv = y.clone()

        y_test = rng.normal(size=6)
        np.testing.assert_allclose(
            logp(y, y_vv).eval({y_vv: y_test}),
            st.norm(np.arange(6), 1).logpdf(y_test),
        )

    def test_split_dims(self):
        rng = np.random.default_rng(164)
        x = pt.random.normal(pt.arange(6), 1, size=(6,))
        y = pt.split_dims(x, shape=(2, 3), axis=0)
        y_vv = y.clone()

        y_test = rng.normal(size=(2, 3))
        np.testing.assert_allclose(
            logp(y, y_vv).eval({y_vv: y_test}),
            st.norm(np.arange(6).reshape((2, 3)), 1).logpdf(y_test),
        )

    @pytest.mark.parametrize("transform_first", (False, True))
    def test_elemwise_chain(self, transform_first):
        rng = np.random.default_rng(165)
        x = pt.random.normal(pt.arange(6).reshape((2, 3)), 1, size=(2, 3))
        y = pt.join_dims(pt.exp(x)) if transform_first else pt.exp(pt.join_dims(x))
        y_vv = y.clone()

        y_test = np.abs(rng.normal(size=6)) + 0.1
        np.testing.assert_allclose(
            logp(y, y_vv).eval({y_vv: y_test}),
            st.norm(np.arange(6), 1).logpdf(np.log(y_test)) - np.log(y_test),
        )

    def test_multivariate_directly_valued(self):
        rng = np.random.default_rng(166)

        # The joined region extends into the support dimension consumed by the logp,
        # so only the remaining batch dimension is re-joined
        x = pt.random.dirichlet(pt.ones(3), size=(2,))
        y = pt.join_dims(x)
        y_vv = y.clone()
        y_test = rng.dirichlet(np.ones(3), size=2).ravel()
        y_logp = logp(y, y_vv).eval({y_vv: y_test})
        assert y_logp.shape == (2,)
        np.testing.assert_allclose(
            y_logp,
            st.dirichlet(np.ones(3)).logpdf(y_test.reshape((2, 3)).T),
        )

        # The split dimension is the support dimension itself
        x2 = pt.random.dirichlet(pt.ones(6))
        y2 = pt.split_dims(x2, shape=(2, 3), axis=0)
        y2_vv = y2.clone()
        y2_test = rng.dirichlet(np.ones(6)).reshape((2, 3))
        y2_logp = logp(y2, y2_vv).eval({y2_vv: y2_test})
        assert y2_logp.shape == ()
        np.testing.assert_allclose(
            y2_logp,
            st.dirichlet(np.ones(6)).logpdf(y2_test.ravel()),
        )

    def test_multivariate_indirect_join_within_batch(self):
        # A join contained in the batch axes leaves the support axes rightmost,
        # so it is measurable even behind other operations
        rng = np.random.default_rng(168)
        x = pt.random.dirichlet(pt.ones(3), size=(2, 2))
        y = pt.exp(pt.join_dims(x, start_axis=0, n_axes=2))
        y_vv = y.clone()
        y_test = np.exp(rng.dirichlet(np.ones(3), size=(2, 2)).reshape((4, 3)))
        y_logp = logp(y, y_vv).eval({y_vv: y_test})
        assert y_logp.shape == (4,)
        np.testing.assert_allclose(
            y_logp,
            st.dirichlet(np.ones(3)).logpdf(np.log(y_test).T) - np.log(y_test).sum(-1),
        )

    def test_multivariate_indirect_join_within_support(self):
        # A join contained in the support axes just deflates them into fewer
        # rightmost axes, so it is measurable even behind other operations
        rng = np.random.default_rng(169)
        x = pm.MatrixNormal.dist(mu=np.zeros((2, 3)), rowcov=np.eye(2), colcov=np.eye(3))
        y = pt.exp(pt.join_dims(x, start_axis=0, n_axes=2))
        y_vv = y.clone()
        y_test = np.exp(rng.normal(size=6))
        # With identity covariances the matrix normal entries are iid standard normal
        np.testing.assert_allclose(
            logp(y, y_vv).eval({y_vv: y_test}),
            st.norm.logpdf(np.log(y_test)).sum() - np.log(y_test).sum(),
        )

    # batch size 1 is the treacherous case: if the straddling join were wrongly
    # claimed, the truncated logp would silently broadcast against the fused value
    # dimension instead of raising a shape error
    @pytest.mark.parametrize("batch_size", (1, 2))
    def test_multivariate_indirect_straddling_join_not_measurable(self, batch_size):
        # A join straddling the batch/support boundary merges batch and support axes;
        # it is only measurable when directly valued
        x = pt.random.dirichlet(pt.ones(3), size=(batch_size,))
        y = pt.exp(pt.join_dims(x))
        with pytest.raises(NotImplementedError):
            logp(y, y.clone())

    def test_multivariate_indirect_split(self):
        # Splitting only inflates a single axis, so it is measurable even for
        # multivariate variables behind other operations
        rng = np.random.default_rng(167)
        x = pt.random.dirichlet(pt.ones(6))
        y = pt.exp(pt.split_dims(x, shape=(2, 3), axis=0))
        y_vv = y.clone()
        y_test = np.exp(rng.dirichlet(np.ones(6)).reshape((2, 3)))
        np.testing.assert_allclose(
            logp(y, y_vv).eval({y_vv: y_test}),
            st.dirichlet(np.ones(6)).logpdf(np.log(y_test).ravel()) - np.log(y_test).sum(),
        )
