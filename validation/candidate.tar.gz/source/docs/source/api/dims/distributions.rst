*************
Distributions
*************

Scalar distributions
====================

.. currentmodule:: pymc.dims
.. autosummary::
   :toctree: generated/
   :template: distribution.rst

   Flat
   HalfFlat
   Uniform,
   Normal
   HalfNormal
   TruncatedNormal
   LogNormal
   StudentT
   HalfStudentT
   Cauchy
   HalfCauchy
   Beta
   Laplace
   Gamma
   InverseGamma
   Wald
   Weibull
   Poisson
   NegativeBinomial
   DiracDelta


Vector distributions
====================

.. currentmodule:: pymc.dims
.. autosummary::
   :toctree: generated/
   :template: distribution.rst

   Categorical
   MvNormal
   ZeroSumNormal


Higher-Order distributions
==========================

.. currentmodule:: pymc.dims
.. autosummary::
   :toctree: generated/
   :template: distribution.rst

   Censored
